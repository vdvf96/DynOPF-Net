#This file load the saved model and plot the results for the test set.
# randomly select a sample from the test set
import matplotlib.pyplot as plt
import numpy as np
import torch

from test import RESULT_DIR

plt.rcParams.update({
    "text.usetex": True,
    "font.family": "Computer Modern Roman",
    "font.sans-serif": ["Computer Modern Sans serif"]})

def plot_results(model, x_test, y_test, DATA_bounds, DATA_balance, Ybus, n_bus, n_gen):
    
    with torch.no_grad():
        y_pred = model(x_test)
        
    idx = torch.randint(0, len(x_test), (1,)).item()
    
    #plotting the Pg
    plt.figure()
    plt.plot(y_pred[idx, :n_gen].cpu()*100, marker="o", label = 'Prediced Power')
    plt.plot(y_test[idx, :n_gen].cpu()*100, '-r' , marker="+", label = 'Actual Power')
    plt.plot(torch.tensor(DATA_bounds['PG_min']).cpu(), '--k')
    plt.plot(torch.tensor(DATA_bounds['PG_max']).cpu(), '--k')
    plt.xlabel('Number of Genrator')
    plt.ylabel('Active Power [MW]')
    plt.xticks(np.arange(len(y_pred[idx, :n_gen])), np.arange(1, len(y_pred[idx, :n_gen])+1))
    plt.legend()
    plt.savefig(RESULT_DIR/ f'Active Power_{n_bus}bus.pdf')
    
    #plotting the Qg
    plt.figure()
    plt.plot(y_pred[idx, n_gen:2*n_gen].cpu()*100, marker="o", label = 'Prediced Power')
    plt.plot(y_test[idx, n_gen:2*n_gen].cpu()*100, '-r' , marker="+", label = 'Actual Power')
    plt.plot(torch.tensor(DATA_bounds['Q_min']).cpu(), '--k')
    plt.plot(torch.tensor(DATA_bounds['Q_max']).cpu(), '--k')
    plt.xlabel('Number of Genrator')
    plt.ylabel('Reactive Power [MVar]')
    plt.xticks(np.arange(len(y_pred[idx, :n_gen])), np.arange(1, len(y_pred[idx, :n_gen])+1))
    plt.legend()
    plt.savefig(RESULT_DIR/ f'Reactive Power_{n_bus}bus.pdf')
    
    #plotting the voltage magnitude
    plt.figure()
    plt.plot(y_pred[idx, 2*n_gen:(2*n_gen + n_bus)].cpu(), marker="o", label = 'Prediced Voltage')
    plt.plot(y_test[idx, 2*n_gen:(2*n_gen + n_bus)].cpu(), '-r', marker="+", label = 'Actual Voltage')
    plt.plot(torch.tensor(DATA_bounds['V_min']).cpu(), '--k')
    plt.plot(torch.tensor(DATA_bounds['V_max']).cpu(), '--k')
    plt.xlabel('Bus')
    plt.ylabel('Magnitude of the Voltage [p.u.]')
    plt.xticks(np.arange(len(y_pred[idx, 2*n_gen:(2*n_gen + n_bus)])), np.arange(1, len(y_pred[idx, 2*n_gen:(2*n_gen + n_bus)])+1))
    plt.legend()
    plt.savefig(RESULT_DIR/ f'Voltage_{n_bus}bus.pdf')
    
    #plotting the theta magnitude
    plt.figure()
    plt.plot(y_pred[idx, (2*n_gen + n_bus):].cpu(), marker="o", label = 'Prediced $\\theta$')
    plt.plot(y_test[idx, (2*n_gen + n_bus):].cpu(), '-r', marker="+", label = 'Actual $\\theta$')
    # plt.plot(torch.tensor(DATA_bounds['V_min']), '--k')
    # plt.plot(torch.tensor(DATA_bounds['V_max']), '--k')
    plt.xlabel('Bus')
    plt.ylabel('Votage Angle [rad]')
    plt.xticks(np.arange(len(y_pred[idx, 2*n_gen:(2*n_gen + n_bus)])), np.arange(1, len(y_pred[idx, 2*n_gen:(2*n_gen + n_bus)])+1))
    plt.legend()
    plt.savefig(RESULT_DIR/ f'Voltage Angle_{n_bus}bus.pdf')
    
def plot_loss(train_loss, val_loss, n_epochs, n_bus):
    plt.figure()
    plt.plot(list(range(n_epochs)), train_loss, label='training loss')
    plt.plot(*zip(*val_loss), label='validation loss')
    plt.xlabel('Number of Epoch')
    plt.ylabel('Loss Value')
    plt.legend()
    plt.savefig(RESULT_DIR/ f'Loss_{n_bus}bus.pdf')

    
    
